const pizzas = [
  {
    name: "PEPPER BARBECUE CHICKEN",
    varient: ["small", "medium", "large"],
    prices: [
      {
        small: 200,
        medium: 350,
        large: 400,
      },
    ],
    category: "nonveg",
    image:
      "https://feenix.co.in/wp-content/uploads/2022/07/424X431pix_Chicken_Sausage-1.jpg",
    description: "Pepper barbecue chicken",
  },
  {
    name: "Veggie Paradise",
    varient: ["small", "medium", "large"],
    prices: [
      {
        small: 200,
        medium: 350,
        large: 400,
      },
    ],
    category: "veg",
    image:
      "https://feenix.co.in/wp-content/uploads/2022/07/424X431pix_Chicken_Sausage-1.jpg",
    description: "Veggie Paradise",
  },
  {
    name: "Non Veg Supreme",
    varient: ["small", "medium", "large"],
    prices: [
      {
        small: 200,
        medium: 350,
        large: 400,
      },
    ],
    category: "nonveg",
    image:
      "https://feenix.co.in/wp-content/uploads/2022/07/424X431pix_Chicken_Sausage-1.jpg",
    description: "Non Veg Supreme",
  },
  {
    name: "Pepperoni pizza",
    varient: ["small", "medium", "large"],
    prices: [
      {
        small: 200,
        medium: 350,
        large: 400,
      },
    ],
    category: "nonveg",
    image:
      "https://feenix.co.in/wp-content/uploads/2022/07/424X431pix_Chicken_Sausage-1.jpg",
    description: "Pepperoni pizza",
  },
  {
    name: "Chicken tikka pizza",
    varient: ["small", "medium", "large"],
    prices: [
      {
        small: 200,
        medium: 350,
        large: 400,
      },
    ],
    category: "nonveg",
    image:
      "https://feenix.co.in/wp-content/uploads/2022/07/424X431pix_Chicken_Sausage-1.jpg",
    description: "Chicken tikka pizza",
  },
  {
    name: "Shrimp pizza",
    varient: ["small", "medium", "large"],
    prices: [
      {
        small: 200,
        medium: 350,
        large: 400,
      },
    ],
    category: "nonveg",
    image:
      "https://feenix.co.in/wp-content/uploads/2022/07/424X431pix_Chicken_Sausage-1.jpg",
    description: "Shrimp pizza",
  },
];

export default pizzas;
