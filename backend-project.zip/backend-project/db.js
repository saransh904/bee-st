const mongoose = require("mongoose");

var mongoURL = 'mongodb+srv://saransh:Shelby1Shelby1@cluster0.tcim9hb.mongodb.net/pizza-project';

mongoose.connect(mongoURL, { useUnifiedTopology: true, useNewUrlParser: true });

var db = mongoose.connection;

db.on('connected', () => {
    console.log('mongo db connection successful');
});

db.on('error', () => {
    console.log('mongo db connection failed');
});

module.exports = mongoose;
